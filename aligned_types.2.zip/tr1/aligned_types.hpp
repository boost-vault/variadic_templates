#ifndef STD_TR1_ALIGNED_TYPES_INCLUDED
#define STD_TR1_ALIGNED_TYPES_INCLUDED
//Purpose:
//  prototype aligned_storage from p. 5 of
//  http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2006/n2140.pdf
//Diffs w.r.t. n2140:
//  Then template names have been changed and extra non-type template
//  parameters added in order to handle alignments from structures
//  besides union.
#include <cstddef>
#include <boost/mpl/fold.hpp>
#include <boost/mpl/package_ops.hpp>
#include <boost/mpl/reverse.hpp>
#include <boost/math/common_factor_ct.hpp>
#include <boost/type_traits/alignment_of.hpp>
#include <boost/aligned_storage.hpp>

namespace std
{
namespace tr1
{

namespace composite_tags
{
    struct variant; //tag for equivalent of aligned_union in n2140.
    struct tuple  ; //tag for similar class for struct instead of union.
    struct packed ; //tag for "packed" tuple.

};
namespace detail
{
  template
  < std::size_t Left
  , std::size_t Right
  >
  struct
compatible_alignment
/**@brief
 *  "Metafunction" returning alignment which is compatible with the 
 *   metafunction argument alignments, Left and Right.
 *
 *  The real reason why this template was created instead of directly using
 *  static_lcm was to provide the documentation shown below which justifies
 *  static_lcm use.
 */
{
        static
      std::size_t const
    value
    = ::boost::math::static_lcm
      < (unsigned long)Left
      , (unsigned long)Right
      >::value
      //The use of static_lcm is based on the statement:
      //
      //  N is the least common multiple of all Alignments
      //
      //in paragraph 1 on page 10 of:
      //
      //  http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2007/n2165.pdf
      //
      //AFAICT, the reason lcm is used instead of just taking the
      //maximum:
      //
      //  Left>Right?Left:Right
      //
      //is to account for "Extended alignments" mentioned in paragraph 3 
      //on page 3 of the n2165 reference mentioned above.  OTOH, if only
      //"Fundamental alignments" are used (which, I assume, are the
      //"static alignments;powers of 2" in paragraph 4 on page 5 of:
      //
      //  http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2006/n2140.pdf
      //
      //) then simply using max instead of lcm would work.
    ;
};
  
  template
  < class AlignmentTag
  , typename... Types
  >
  struct 
composite_partial
;
  template
  < class Tag
  >
  struct 
composite_partial
  < Tag
  >
{
        static
      std::size_t const
    size_part
    = 0
    ;
        static
      std::size_t const
    alignment_part
    = 1
    ;
};
}//exit detail namespace
namespace detail//composite_tags::variant
{
  template
  < typename Head
  , typename... Tail
  >
  struct 
composite_partial
  < composite_tags::variant
  , Head
  , Tail...
  >
{
        typedef
      composite_partial
      < composite_tags::variant
      , Tail...
      >
    tail_type
    ;
        static
      std::size_t const
    size_part
    = tail_type::size_part > sizeof(Head)
    ? tail_type::size_part
    : sizeof(Head)
    ;
        static
      std::size_t const
    alignment_one
    = ::boost::alignment_of<Head>::value
    ;
        static
      std::size_t const
    alignment_part
    = compatible_alignment
      < alignment_one
      , tail_type::alignment_part
      >::value
    ;
};
}//exit detail namespace//composite_tags::variant

  template
  < class Tag
  , typename... Types
  >
  struct
aligned_types
;
  template
  < typename... Types
  >
  struct
aligned_types
  < composite_tags::variant
  , Types...
  >
{
        typedef
      detail::composite_partial
      < composite_tags::variant
      , Types...
      >
    composite_type
    ;
        static
      std::size_t const
    alignment_value
    = composite_type::alignment_part
    ;
        typedef
        typename
      ::boost::aligned_storage
      < composite_type::size_part
      , alignment_value
      >::type
    type
    ;
};

namespace detail
{
  template
  < class Tag
  , typename Package
  >
  struct
composite_pkg
;
  template
  < class Tag
  , typename... Types
  >
  struct
composite_pkg
  < Tag
  , ::boost::mpl::package<Types...>
  >
/**@brief
 *  Helper template which takes package<Types...> instead
 *  of Types...  This is needed because for some
 *  templates below, Types... needs
 *  to be reversed first and the method chosen for this
 *  was to put it in a package and use mpl::reverse.
 *  The result of this is another package, i.e. the
 *  arg to this template.
 */  
{
        typedef
      composite_partial
      < Tag
      , Types...
      >
    type
    ;
};
  template
  < class Tag
  , typename... Types
  >
  struct
composite_reverse
{
        typedef
      ::boost::mpl::package<Types...>
    pkg_types
    ;
        typedef
        typename
      ::boost::mpl::reverse
      < pkg_types
      , ::boost::mpl::back_inserter
        < ::boost::mpl::package<>
        >
      >::type
    rev_types
    ;
        typedef
        typename
      detail::composite_pkg
      < Tag
      , rev_types
      >::type
    type
    ;
};

}//exit detail namespace
namespace detail//composite_tags::packed
{
  template
  < typename Head
  , typename... Tail
  >
  struct 
composite_partial
  < composite_tags::packed
  , Head
  , Tail...
  >
:     composite_partial
      < composite_tags::packed
      , Tail...
      >
      //inheirit the alignment_part
{
        typedef
      composite_partial
      < composite_tags::packed
      , Tail...
      >
    tail_type
    ;
        static
      std::size_t const
    size_part
    = tail_type::size_part
    + sizeof(Head)
    ;
};

}//exit detail namespace//composite_tags::packed

namespace detail//composite_tags::tuple
{
  template
  < std::size_t Offset
  , std::size_t Alignment
  >
  struct
next_aligned_offset
{
        static
      std::size_t const
    remainder
    = Offset%Alignment
    ;
        static
      std::size_t const
    value
    = remainder == 0
    ? Offset
    : Offset+(Alignment-remainder)
    //value is minimum value > Offset such that
    //value%Alignment == 0
    ;
    
};  

  struct
tag_tuple_fields
;
  template
  < typename Head
  , typename... Tail
  >
  struct 
composite_partial
  < tag_tuple_fields
  , Head
  , Tail...
  >
{
        static
      std::size_t const
    alignment_one
    = ::boost::alignment_of<Head>::value
    ;
        typedef
      composite_partial
      < tag_tuple_fields
      , Tail...
      >
    tail_type
    ;
        static
      std::size_t const
    alignment_part
    = compatible_alignment
      < tail_type::alignment_part
      , alignment_one
      >::value
    ;
        static
      std::size_t const
    size_part
    = next_aligned_offset
      <   tail_type::size_part 
        + sizeof(Head)
      , alignment_one
      >::value
    ;
};

  template
  < typename Head
  , typename... Tail
  >
  struct 
composite_partial
  < composite_tags::tuple
  , Head
  , Tail...
  >
/**@brief
 *  Implements method described 
 *  in aligned_struct_offsets.txt 
 *  on 10 Apr 2007
 *  at http://boost-consulting.com/vault/index.php?directory=variadic_templates
 */  
{
        static
      std::size_t const
    alignment_one
    = ::boost::alignment_of<Head>::value
    ;
        typedef
      composite_partial
      < tag_tuple_fields
      , Tail...
      >
    tail_type
    ;
        static
      std::size_t const
    alignment_part
    = compatible_alignment
      < tail_type::alignment_part
      , alignment_one
      >::value
    ;
        static
      std::size_t const
    size_part
    = next_aligned_offset
      <   tail_type::size_part 
        + sizeof(Head)
      , alignment_part 
        //size of whole composite must be divisible by 
        //maximum alignment(i.e. alignment_part)
        //to handle alignment within arrays.
      >::value
    ;
};

}//exit detail namespace//composite_tags::tuple

  template
  < class Tag
  , typename... Types
  >
  struct
aligned_types
{
        typedef
        typename
      detail::composite_reverse
      < Tag
      , Types...
      >::type
    composite_type
    ;
        static
      std::size_t const
    alignment_value
    = composite_type::alignment_part
    ;
        typedef
        typename
      ::boost::aligned_storage
      < composite_type::size_part
      , alignment_value
      >::type
    type
    ;
};
   
namespace detail
/**@brief
 *  This section defines composite_at, a template
 *  for accessing the different parts of composite_partial's.
 */
{
    
  template
  < typename Sequence
  , unsigned Index
  >
  struct
composite_at
;  
  template
  < class Tag
  , typename Head
  , typename... Tail
  , unsigned Index
  >
  struct
composite_at
  < composite_partial
    < Tag
    , Head
    , Tail...
    >
  , Index
  >
: composite_at
  < composite_partial
    < Tag
    , Tail...
    >
  , Index-1
  >
{
        typedef
      composite_at
    type
    ;    
};  
  template
  < class Tag
  , typename Head
  , typename... Tail
  >
  struct
composite_at
  < composite_partial
    < Tag
    , Head
    , Tail...
    >
  , 0
  >
: composite_partial
  < Tag
  , Head
  , Tail...
  >
{    
        typedef
      composite_at
    type
    ;    
};  
  template
  < class Tag
  >
  struct
composite_at
  < composite_partial
    < Tag
    >
  , 0
  >
: composite_partial
  < Tag
  >
{    
        typedef
      composite_at
    type
    ;    
};  

}//exit detail namespace
}//exit tr1 namespace
}//exit std namespace
#include <boost/mpl/at.hpp>
namespace boost
{
namespace mpl
{
  template
  < class Tag
  , typename... Types
  , long Index
  >
  struct
at_c
  < std::tr1::aligned_types
    < Tag
    , Types...
    >
  , Index
  >
{
        typedef
        typename
      std::tr1::aligned_types
      < Tag
      , Types...
      >::composite_type
    composite_type
    ;
        typedef
        typename
      std::tr1::detail::composite_at    
      < composite_type
      , sizeof...(Types)-Index
      >::type
    type
    ;
}; 
}};
#endif
