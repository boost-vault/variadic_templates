//Purpose:
//  Test tr1::aligned_types.hpp
//ChangeLog:
//  2007-03-28.0732
//    cp'ed/modified from aligned_storage_test.cpp
#include <tr1/aligned_types.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/package_c_ops.hpp>
#include <boost/tuple/tuple.hpp>

namespace std
{
namespace tr1
{

  template
  < unsigned I
  >
  struct
type_i
{
    char c[(I+1)*10+I];
    typedef type_i type;
};

  template
  <
  >
  struct
type_i
  < 1
  >
{
    typedef short type;
};
  template
  <
  >
  struct
type_i
  < 2
  >
{
    typedef double type;
};

    typedef
  aligned_types
  < composite_tags::variant
  , type_i<0>::type
  , type_i<1>::type
  , type_i<2>::type
  >
aligned_variant_type
;
  aligned_variant_type
a_aligned_variant_valu
;
    typedef
  aligned_variant_type::composite_type
composite_variant_type
;
    typedef
  ::boost::mpl::package_c
  < size_t
  , detail::composite_at<composite_variant_type,0>::alignment_one
  , detail::composite_at<composite_variant_type,1>::alignment_one
  , detail::composite_at<composite_variant_type,2>::alignment_one
  >
alignof_actual
;  
    typedef
  ::boost::mpl::package_c
  < size_t
  , ::boost::alignment_of<type_i<0>::type >::value
  , ::boost::alignment_of<type_i<1>::type >::value
  , ::boost::alignment_of<type_i<2>::type >::value
  >
alignof_expected
;  
BOOST_MPL_ASSERT((boost::is_same<alignof_actual,alignof_expected>));
    typedef
  aligned_types
  < composite_tags::packed
  , type_i<0>::type
  , type_i<1>::type
  , type_i<2>::type
  >
aligned_packed_type
;
  aligned_packed_type
a_aligned_packed_valu
;
    typedef
  aligned_packed_type::composite_type
composite_packed_type
;
    static
  std::size_t const
at_0_packed_expected
= sizeof(type_i<0>::type)
+ sizeof(type_i<1>::type)
+ sizeof(type_i<2>::type)
;    
BOOST_MPL_ASSERT_RELATION(composite_packed_type::size_part,==,at_0_packed_expected);
    typedef
  detail::composite_at
  < composite_packed_type
  , 0
  >
at_0_packed_actual
;  
BOOST_MPL_ASSERT_RELATION(at_0_packed_actual::size_part,==,at_0_packed_expected);
    typedef
  detail::composite_at
  < composite_packed_type
  , 1
  >
at_1_packed_actual
;  
    static
  std::size_t const
at_1_packed_expected
= sizeof(type_i<0>::type)
+ sizeof(type_i<1>::type)
;    
BOOST_MPL_ASSERT_RELATION(at_1_packed_actual::size_part,==,at_1_packed_expected);
    typedef
  detail::composite_at
  < composite_packed_type
  , 2
  >
at_2_packed_actual
;  
    static
  std::size_t const
at_2_packed_expected
= sizeof(type_i<0>::type)
;    
BOOST_MPL_ASSERT_RELATION(at_2_packed_actual::size_part,==,at_2_packed_expected);
    typedef
  detail::composite_at
  < composite_packed_type
  , 3
  >
at_3_packed_actual
;  
    static
  std::size_t const
at_3_packed_expected
= 0
;    
BOOST_MPL_ASSERT_RELATION(at_3_packed_actual::size_part,==,at_3_packed_expected);

BOOST_MPL_ASSERT_RELATION((::boost::mpl::at_c<aligned_packed_type,0>::type::size_part),==,at_3_packed_expected);
BOOST_MPL_ASSERT_RELATION((::boost::mpl::at_c<aligned_packed_type,1>::type::size_part),==,at_2_packed_expected);
BOOST_MPL_ASSERT_RELATION((::boost::mpl::at_c<aligned_packed_type,2>::type::size_part),==,at_1_packed_expected);
BOOST_MPL_ASSERT_RELATION((::boost::mpl::at_c<aligned_packed_type,3>::type::size_part),==,at_0_packed_expected);

    typedef
  aligned_types
  < composite_tags::tuple
  , type_i<0>::type
  , type_i<1>::type
  , type_i<2>::type
  >
aligned_tuple_type
;
    typedef
  ::boost::mpl::at_c
  < aligned_tuple_type
  , 0
  >::type
at_0_tuple_actual
;  
    typedef
  ::boost::mpl::at_c
  < aligned_tuple_type
  , 1
  >::type
at_1_tuple_actual
;  
    typedef
  ::boost::mpl::at_c
  < aligned_tuple_type
  , 2
  >::type
at_2_tuple_actual
;  
    typedef
  ::boost::mpl::at_c
  < aligned_tuple_type
  , 3
  >::type
at_3_tuple_actual
;  
  struct
tuple_type_expected
{
      type_i<0>::type
    f_0
    ;
      type_i<1>::type
    f_1
    ;
      type_i<2>::type
    f_2
    ;
};

  std::size_t const
at_3_tuple_expected
=sizeof(tuple_type_expected)
;  
  std::size_t const
at_2_tuple_expected
=offsetof(tuple_type_expected,f_2)
;  
  std::size_t const
at_1_tuple_expected
=offsetof(tuple_type_expected,f_1)
;  
  std::size_t const
at_0_tuple_expected
=offsetof(tuple_type_expected,f_0)
;  

BOOST_MPL_ASSERT_RELATION(at_3_tuple_actual::size_part,==,at_3_tuple_expected);
BOOST_MPL_ASSERT_RELATION(at_2_tuple_actual::size_part,==,at_2_tuple_expected);
BOOST_MPL_ASSERT_RELATION(at_1_tuple_actual::size_part,==,at_1_tuple_expected);
BOOST_MPL_ASSERT_RELATION(at_0_tuple_actual::size_part,==,at_0_tuple_expected);

    typedef
  ::boost::tuple
  < type_i<0>::type
  , type_i<1>::type
  , type_i<2>::type
  >
tuple_type
;  
BOOST_MPL_ASSERT_RELATION(at_3_tuple_actual::size_part,<,sizeof(tuple_type));
}//exit tr1 namespace  
}//exit std namespace  
