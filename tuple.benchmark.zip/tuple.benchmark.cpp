#define LAST_ROW LAST_RC
#define LAST_COL LAST_RC

/*=============================================================================
    Copyright (c) 2009 Christopher Schmidt

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/

//OriginalVersion:
//  On 2009-09-27, downloaded from attachment to:
//    http://article.gmane.org/gmane.comp.lib.boost.devel/194407
//Purpose:
//  Timing benchmark for 2 methods of tuple implmentation.
//  The method used is dependent on macro, VERTICAL:
//    when #define VERTICAL:
//      This method uses the boost preprocessor to generate
//      member variables for the tuple elements:
//        HI tI;
//      where I=0...N-1, where N is the size of the tuple.
//    when #undef VERTICAL:
//      This method uses multiple inheritance of the
//      tuple elements "paired" with a key in a 
//      superclass:
//        element<identity_int<I>,HI>
//      where I is as for the '#define VERTICAL' method and
//      where the member variable is:
//        HI element<identity_int<I>,HI>::a;
//
template<int>
struct identity_int
{};

#ifdef VERTICAL
  template<int Index,typename... Args>
  struct tuple_impl;
  template<int Index>
  struct tuple_impl<Index>
  {};
  template<int Index,typename H0>
  struct tuple_impl<Index,H0>
  {
  	typedef H0 t0;
  	H0 h0;
  	H0& get(identity_int<Index+0>){return h0;}
  	H0 const& get(identity_int<Index+0>)const{return h0;}
  };
  template<int Index,typename H0, typename H1>
  struct tuple_impl<Index,H0,H1>
  {
  	typedef H0 t0; typedef H1 t1;
  	H0 h0;
  	H0& get(identity_int<Index+0>){return h0;}
  	H0 const& get(identity_int<Index+0>)const{return h0;}
  	H1 h1;
  	H1& get(identity_int<Index+1>){return h1;}
  	H1 const& get(identity_int<Index+1>)const{return h1;}
  };
  
  template<int Index,typename H0, typename H1, typename H2>
  struct tuple_impl<Index,H0,H1,H2>
  {
  	typedef H0 t0; typedef H1 t1; typedef H2 t2;
  	H0 h0;
  	H0& get(identity_int<Index+0>){return h0;}
  	H0 const& get(identity_int<Index+0>)const{return h0;}
  	H1 h1;
  	H1& get(identity_int<Index+1>){return h1;}
  	H1 const& get(identity_int<Index+1>)const{return h1;}
  	H2 h2;
  	H2& get(identity_int<Index+2>){return h2;}
  	H2 const& get(identity_int<Index+2>)const{return h2;}
  };
  template<int Index,typename H0, typename H1, typename H2, typename H3>
  struct tuple_impl<Index,H0,H1,H2, H3>
  {
  	typedef H0 t0; typedef H1 t1; typedef H2 t2; typedef H3 t3;
  	H0 h0;
  	H0& get(identity_int<Index+0>){return h0;}
  	H0 const& get(identity_int<Index+0>)const{return h0;}
  	H1 h1;
  	H1& get(identity_int<Index+1>){return h1;}
  	H1 const& get(identity_int<Index+1>)const{return h1;}
  	H2 h2;
  	H2& get(identity_int<Index+2>){return h2;}
  	H2 const& get(identity_int<Index+2>)const{return h2;}
  	H3 h3;
  	H3& get(identity_int<Index+3>){return h3;}
  	H3 const& get(identity_int<Index+3>)const{return h3;}
  };
  template<int Index,typename H0, typename H1, typename H2, typename H3, typename... Others>
  struct tuple_impl<Index,H0,H1,H2, H3,Others...>:
  	tuple_impl<Index+4,Others...>
  {
  	typedef tuple_impl<Index+4,Others...> base;
  	typedef H0 t0; typedef H1 t1; typedef H2 t2; typedef H3 t3;
  	using base::get;
  	H0 h0;
  	H0& get(identity_int<Index+0>){return h0;}
  	H0 const& get(identity_int<Index+0>)const{return h0;}
  	H1 h1;
  	H1& get(identity_int<Index+1>){return h1;}
  	H1 const& get(identity_int<Index+1>)const{return h1;}
  	H2 h2;
  	H2& get(identity_int<Index+2>){return h2;}
  	H2 const& get(identity_int<Index+2>)const{return h2;}
  	H3 h3;
  	H3& get(identity_int<Index+3>){return h3;}
  	H3 const& get(identity_int<Index+3>)const{return h3;}
  };
  template<typename... Args>
  struct tuple:
  	tuple_impl<0,Args...>
  {};
  
  template<typename Tuple, int Index>
  struct meta_value_at:
  	meta_value_at<typename Tuple::base, Index-4>
  {};
  template<typename Tuple>
  struct meta_value_at<Tuple,0>
  {
  	typedef typename Tuple::t0 type;
  };
  template<typename Tuple>
  struct meta_value_at<Tuple,1>
  {
  	typedef typename Tuple::t1 type;
  };
  template<typename Tuple>
  struct meta_value_at<Tuple,2>
  {
  	typedef typename Tuple::t2 type;
  };
  template<typename Tuple>
  struct meta_value_at<Tuple,3>
  {
  	typedef typename Tuple::t3 type;
  };
#else
  template<int Max,int... Args>
  struct make_package:
  	make_package<Max-1,Max-1,Args...>
  {};
  template<int...>
  struct package
  ;
  template<int... Args>
  struct make_package<0,Args...>
  {
  	typedef package<Args...> type;
  };
  
  template<typename, typename Arg>
  struct element{Arg a;}
  ;
  template<typename Keys, typename... Args>
  struct tuple_impl
  ;
  template<int... Indices, typename... Args>
  struct tuple_impl<package<Indices...>, Args...>:
  	element<identity_int<Indices>, Args>... 
  {};
  
  template<typename... Args>
  struct tuple:
  	tuple_impl<typename make_package<sizeof...(Args)>::type, Args...> 
  {
   	template<int I, typename T>
  	static T& at_elem(element<identity_int<I>,T>& a){return a.a;}
  	template<int I, typename T>
  	static T const& at_elem(element<identity_int<I>,T>const& a){return a.a;}
        
 	template<int I, typename T>
  	static T at_type_helper(element<identity_int<I>,T>& a); 
  	template<int I>
  	struct at_type
  	{
  		typedef decltype(at_type_helper<I>(*static_cast<tuple*>(0))) type;
  	};
  };
#endif

template<int I,int J, int Max, typename... Args>
struct get_tuple:
	get_tuple<I,J,Max-1,identity_int<I*1000+J*10+Max>,Args...>
{};
template<int I,int J, typename... Args>
struct get_tuple<I,J,0, Args...>
{
	typedef tuple<Args...> type;
};

template<int I,int J=0>
struct test_row
{
	typedef typename get_tuple<I, J, J%10>::type tuple_type;

	template<int K>
	static void at_test(tuple_type& t,identity_int<K>)
	{
#ifdef TYPE_AT
#	ifdef VERTICAL
		typename meta_value_at<tuple_type,K>::type();
#	else
		typename tuple_type::template at_type<K>::type();
#	endif
#endif
#ifdef ELEM_AT
#	ifdef VERTICAL
		t.get(identity_int<K>());
#	else
		tuple_type::template at_elem<K>(t);
#	endif
#endif

		at_test(t,identity_int<K+1>());
	}
	static void at_test(tuple_type&,identity_int<J%10>){}

	static void exec()
	{
		tuple_type t;
		at_test(t,identity_int<0>());
                //The combination of the above at_test specialized function
                //and the at_test general function means the above call
                //actually calls:
                //  at_test'<K>
                //for k=0...J%10-1
                //where at_test' is just at_test without the
                //recursive call to at_test<K+1>(...).
		test_row<I,J+1>::exec();
	}
};
template<int I>
struct test_row<I,LAST_ROW>
{
	static void exec(){}
};

//The combination of the above test_row special and the preceding general
//templates means the call:
//  test_row<I>::exec()
//executes:
//  test_row<I,J>::exec'()
//for J=0...LAST_ROW
//where exec' is exec without the recursive call to test_row<I,J+1>::exec().

template<int I=0>
struct test_col
{
	static void exec()
	{
		test_row<I>::exec();
		test_col<I+1>::exec();
	}
};

template<>
struct test_col<LAST_COL>
{
	static void exec(){}
};


int main()
{
	test_col<>::exec();
        //The combination of the test general and special templates
        //means the above call executes:
        //  test_row<I>::exec() 
        //for I=0...LAST_COL
}
